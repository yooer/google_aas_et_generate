# JSON

- https://github.com/ytdl-org/youtube-dl/issues/24484
- https://godocs.io/encoding/xml#Decoder.Strict

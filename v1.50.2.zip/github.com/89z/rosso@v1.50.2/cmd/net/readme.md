# Net

- <https://wikipedia.org/wiki/URL_redirection>
- https://curl.se/docs/manpage.html#-L
- https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/301

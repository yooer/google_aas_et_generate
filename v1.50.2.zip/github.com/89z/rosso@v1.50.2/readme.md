# Rosso

> Yeah so it sounds like you and me had the same journey here, and uh yeah I'm
> glad to find someone who's on the other side of it. So uh tell me what did you
> do?
>
> Uh what do you mean?
>
> Like what do you do?
>
> I mean I hit both shift keys, and I type the letters with my nose.
>
> I know that that's what I've been doing too, but what did you do so you don't
> have to do that anymore?
>
> No that's what I do.
>
> [Joel Haver (2021)](//youtube.com/watch?v=hnUpTyKSjag)

Data parsers and formatters

## Topics

- DASH
- HLS
- HTTP
- JA3
- JSON
- MP4
- ProtoBuf
- XML

## Money

I only provide paid support for issues. Any issue without payment of at least
9 USD will be closed immediately. Payment can be made to one of:

- https://github.com/sponsors/89z
- <https://paypal.com/donate?hosted_button_id=UEJBQQTU3VYDY>

Software is not licensed for commercial use. If you wish to purchase a
commercial license, or for other business questions, contact me:

- srpen6@gmail.com
- Discord srpen6#6983

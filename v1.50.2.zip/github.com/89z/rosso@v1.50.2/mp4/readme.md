# MP4

- https://github.com/edgeware/mp4ff/issues/150
- https://w3.org/TR/eme-stream-mp4

## AMC

~~~
go run . -b 1011152 -f 9999999 -g 0
~~~

key:

~~~
a66a5603545ad206c1a78e160a6710b1
~~~

https://amcplus.com/shows/orphan-black/episodes/season-1-instinct--1011152

## Paramount

~~~
go run . -d -b eyT_RYkqNuH_6ZYrepLtxkiPO1HA7dIU -f 9999999 -g 0
~~~

key:

~~~
44f12639c9c4a5a432338aca92e38920
~~~

<https://paramountplus.com/shows/video/eyT_RYkqNuH_6ZYrepLtxkiPO1HA7dIU>

## Roku

~~~
go run . -d -b 597a64a4a25c5bf6af4a8c7053049a6f -f 9999999 -g 0
~~~

key:

~~~
13d7c7cf295444944b627ef0ad2c1b3c
~~~

https://therokuchannel.roku.com/watch/597a64a4a25c5bf6af4a8c7053049a6f

# DASH

ISO/IEC 23009-1:2019

- <https://wikipedia.org/wiki/Dynamic_Adaptive_Streaming_over_HTTP>
- https://github.com/golang/go/blob/master/src/go/types/testdata/check/slices.go
- https://standards.iso.org/ittf/PubliclyAvailableStandards
- https://w3.org/TR/ttml1
- https://w3.org/TR/webvtt1
